import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import styles from './App.module.css'
import Recipes from './components/Recipes'
import RecipeDetail from './components/RecipeDetail'
import Likes from './components/like'








export default function App() {

  return(

    
   
    <BrowserRouter>
    <div className={styles.app}>
      <nav className={styles.navbar}>
        <Link to="/">Home</Link>
      </nav>
      <section className={styles.likes}>
      <Likes />
      </section>
    
    <div className={styles.container}>
    <Routes>
      <Route path="/" element={<Recipes />} />
      <Route path="/recipe/:id" element={<RecipeDetail />} />
      
    </Routes>
    
    

   
    
    </div>
    
  
 
    

   

    <footer><a href="#">Pagefooter</a></footer>
    </div>
    
    </BrowserRouter>
  )
  
 

  
}