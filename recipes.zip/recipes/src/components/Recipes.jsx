import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Card, CardContent, CardMedia, Button, Grid, Typography } from '@mui/material'

export default function Recipes() {
    const [recipes, setRecipes] = useState([])
    const navigate = useNavigate()

    useEffect(() => {
        const fetchRecipes = async () => {
            try {
                const res = await fetch("https://dummyjson.com/recipes")
                const data = await res.json()
                setRecipes(data.recipes)
            } catch (error) {
                console.error("Fejl ved hentning af opskrifter:", error)
            }
        }

        fetchRecipes();
    }, []);

    return (
        <Grid container spacing={3} justifyContent="center" sx={{ marginTop: 2 }}>
            {recipes.map((recipe) => (
                <Grid item key={recipe.id} xs={12} sm={6} md={4} lg={3}>
                    <Card sx={{ maxWidth: 345 }}>
                        <CardMedia component="img" height="200" image={recipe.image} alt={recipe.name} />
                        <CardContent>
                            <Typography gutterBottom variant="h5" component="div">
                                {recipe.name}
                            </Typography>
                        </CardContent>
                        <Button
                        variant="contained"
                        color="primary"
                        fullwidth
                        onClick={() => navigate(`/recipe/${recipe.id}`)}>
                            Læs Mere
                        </Button>
                    </Card>
                </Grid>
            ))}
        </Grid>
    )
}