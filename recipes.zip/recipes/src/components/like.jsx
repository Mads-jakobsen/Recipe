import { useState } from 'react'





export default function Likes() {
  const [count, setLikes] = useState(0);
  return (
    <div>
      <p>Likes {count} </p>

      <button onClick={() => setLikes (count + 1 )}><i class="fa-solid fa-thumbs-up"></i></button>
    </div>
    )
  

}
